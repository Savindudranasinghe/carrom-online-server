const WebSocket = require("ws");
const http = require("http");
const fs = require("fs");
const path = require("path");
const {RULES,initialState,legalTurn,nextTurn,applyShotResult} = require('./rules');
const {simulateShot}=require('./physics');

const PORT = process.env.PORT || 8080;
const rooms = new Map();

function code() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  do { s = Array.from({length:6},()=>chars[Math.floor(Math.random()*chars.length)]).join(""); }
  while (rooms.has(s));
  return s;
}


function makeFormation(){
  const out=[]; let id=0;
  out.push({id:id++,type:"q",x:360,y:360,r:17,vx:0,vy:0,pocketed:false});
  const ring=[
    [-29,0,"w"],[29,0,"b"],[-14.5,-25,"b"],[14.5,-25,"w"],
    [-14.5,25,"w"],[14.5,25,"b"],[-50,-29,"w"],[0,-29,"b"],[50,-29,"w"],
    [-50,29,"b"],[0,29,"w"],[50,29,"b"],[-58,0,"b"],[58,0,"w"],
    [-43,-25,"w"],[43,-25,"b"],[-43,25,"b"],[43,25,"w"]
  ];
  for(const [x,y,type] of ring) out.push({id:id++,type,x:360+x,y:360+y,r:17,vx:0,vy:0,pocketed:false});
  return out;
}
function broadcast(room) {
  const msg = JSON.stringify({
    type:"room_state",
    room: room.id,
    mode: room.mode,
    players: room.players.map(p => p ? {id:p.id,name:p.name,ready:p.ready,slot:p.slot} : null)
  });
  room.players.forEach(p => p && p.ws.readyState === WebSocket.OPEN && p.ws.send(msg));
}

function send(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

const server = http.createServer((req,res)=>{
  if (req.url === "/health") { res.writeHead(200,{"Content-Type":"application/json"}); return res.end(JSON.stringify({ok:true,rooms:rooms.size})); }

  const file = req.url === "/" ? "index.html" : req.url.slice(1);
  const safe = path.join(__dirname, path.normalize(file));
  if (!safe.startsWith(__dirname)) return res.writeHead(403).end();
  fs.readFile(safe,(err,data)=>{
    if(err) return res.writeHead(404).end("Not found");
    res.writeHead(200,{"Content-Type":file.endsWith(".html")?"text/html":"text/plain"});
    res.end(data);
  });
});

const wss = new WebSocket.Server({server});

wss.on("connection", ws => {
  const player = {ws,id:Math.random().toString(36).slice(2),name:"Player",ready:false,slot:null,room:null};

  ws.on("message", raw => {
    let m; try { m=JSON.parse(raw); } catch { return send(ws,{type:"error",message:"Invalid message"}); }

    if(m.type==="create"){
      const id=code();
      const room={id,mode:m.mode==="2v2"?"2v2":"1v1",players:[null,null,null,null],state:{...initialState(m.mode==="2v2"?"2v2":"1v1"),coins:makeFormation(),striker:{x:360,y:605,r:21,vx:0,vy:0,pocketed:false}}};
      player.name=(m.name||"Player").slice(0,20);
      player.slot=0; player.room=room; room.players[0]=player; rooms.set(id,room);
      send(ws,{type:"created",room:id}); broadcast(room); return;
    }

    if(m.type==="join"){
      const room=rooms.get(String(m.room||"").toUpperCase());
      if(!room) return send(ws,{type:"error",message:"Room not found"});
      const max=room.mode==="2v2"?4:2;
      const slot=room.players.findIndex(p=>!p);
      if(slot<0 || slot>=max) return send(ws,{type:"error",message:"Room is full"});
      player.name=(m.name||"Player").slice(0,20);
      player.slot=slot; player.room=room; room.players[slot]=player;
      send(ws,{type:"joined",room:room.id}); broadcast(room); return;
    }

    if(m.type==="ready"){
      if(!player.room) return;
      player.ready=!!m.ready; broadcast(player.room); return;
    }

    if(m.type==="break_lock"){
      const room=player.room; if(!room) return;
      if(player.slot!==0 || !room.players.filter(Boolean).every(p=>p.ready)) return send(ws,{type:"error",message:"Break can only be locked by Player 1 after all players are ready"});
      if(room.state.breakLocked) return send(ws,{type:"error",message:"Break already locked"});
      const a=Number(m.angle); if(!Number.isFinite(a)) return send(ws,{type:"error",message:"BAD_ANGLE"});
      room.state.formationAngle=((a%360)+360)%360;
      room.state.breakLocked=true;
      room.state.shot.startedAt=Date.now();
      room.players.forEach(p=>p&&send(p.ws,{type:"break_locked",state:room.state}));
      return;
    }

    // Server-authoritative match messages: clients send intents, not scores.
    if(m.type==="shot_intent"){
      const room=player.room; if(!room) return;
      const readyPlayers=room.players.filter(Boolean);
      const needed=room.mode==="2v2"?4:2;
      if(readyPlayers.length<needed || !readyPlayers.every(p=>p.ready))
        return send(ws,{type:"error",message:"All players must be ready"});
      if(!legalTurn(room.state,player.slot))
        return send(ws,{type:"error",message:"Out of turn"});
      if(Date.now()-room.state.shot.startedAt > RULES.shotSeconds*1000){
        nextTurn(room.state);
        return send(ws,{type:"error",message:"15-second turn expired"});
      }
      if(!room.state.breakLocked) return send(ws,{type:"error",message:"BREAK_NOT_LOCKED"});
      const sim=simulateShot(room.state,{x:m.x,y:m.y,power:m.power});
      if(!sim.ok) return send(ws,{type:"error",message:sim.reason});
      const ownType=room.mode==="1v1" ? (player.slot===0?"w":"b") : ((player.slot%2===0)?"w":"b");
      const ownPocketed=sim.pocketed.filter(x=>x.type===ownType).length;
      const opponentPocketed=sim.pocketed.filter(x=>x.type!=="q"&&x.type!==ownType).length;
      const queenPocketed=sim.pocketed.some(x=>x.type==="q");
      room.state.coins=sim.pieces;
      room.state.striker={x:360,y:605,r:21,vx:0,vy:0,pocketed:false};
      const result=applyShotResult(room.state,player.slot,{ownPocketed,opponentPocketed,queenPocketed,strikerPocketed:sim.strikerPocketed});
      if(!result.ok) return send(ws,{type:"error",message:result.reason});
      room.state.lastShot={player:player.slot,trajectory:{x:Number(m.x),y:Number(m.y),power:Number(m.power)},pocketed:sim.pocketed};
      room.players.forEach(p=>p&&send(p.ws,{type:"shot_resolved",state:room.state,result}));
    }

    if(m.type==="sync_request"){
      if(player.room) send(ws,{type:"state_sync",state:player.room.state||null});
    }
  });

  ws.on("close",()=>{
    const room=player.room;
    if(!room) return;
    if(room.players[player.slot]===player) room.players[player.slot]=null;
    broadcast(room);
    if(room.players.every(p=>!p)) rooms.delete(room.id);
  });
});

server.listen(PORT,()=>console.log(`Carrom server running on http://localhost:${PORT}`));
