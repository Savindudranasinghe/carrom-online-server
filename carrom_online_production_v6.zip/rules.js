
// Canonical, server-side Carrom rule helpers.
// Clients submit shot intent; the server owns turn, timer, scoring and foul decisions.
const RULES = Object.freeze({
  shotSeconds: 15,
  maxBoards: 8,
  maxGames: 3,
  targetPoints: 25,
  queenPoints: 3,
  piecesPerSide: 9
});

function initialState(mode="1v1") {
  return {
    mode,
    turn: 0,
    board: 1,
    game: 1,
    scores: [0,0,0,0],
    queen: {status:"open", owner:null},
    coins: [],
    striker: {pocketed:false},
    shot: {startedAt:Date.now(), number:0},
    winner:null,
    breakLocked:false,
    formationAngle:0
  };
}

function legalTurn(state, slot) {
  if (state.mode === "1v1") return slot === state.turn;
  return slot === state.turn; // 0→1→2→3 in doubles
}

function nextTurn(state) {
  state.turn = state.mode === "1v1" ? (state.turn ? 0 : 1) : ((state.turn + 1) % 4);
  state.shot.startedAt = Date.now();
}

function applyShotResult(state, slot, result) {
  if (!legalTurn(state, slot)) return {ok:false, reason:"OUT_OF_TURN"};
  if (Date.now() - state.shot.startedAt > RULES.shotSeconds*1000)
    return {ok:false, reason:"TIMEOUT"};

  const own = Number(result.ownPocketed || 0);
  const opponent = Number(result.opponentPocketed || 0);
  const queen = !!result.queenPocketed;
  const striker = !!result.strikerPocketed;

  // Server receives a physics result only after validating it against canonical simulation.
  // These bookkeeping rules encode the competitive turn/scoring layer.
  if (striker) {
    if (own > 0) state.scores[slot] = Math.max(0, state.scores[slot] - 1);
    nextTurn(state);
    return {ok:true, type:"FOUL", reason:"STRIKER_POCKET"};
  }

  if (queen) {
    if (own > 0) {
      state.queen.status="covered";
      state.queen.owner=slot;
      state.scores[slot] += RULES.queenPoints;
    } else {
      state.queen.status="open";
      state.queen.owner=null;
    }
  }
  state.scores[slot] += own;
  if (opponent > 0) state.scores[slot] += 0; // opponent coins do not score for this player.

  // Pocketing own coin legally keeps the turn; otherwise pass.
  if (own === 0) nextTurn(state);
  else state.shot.startedAt=Date.now();

  return {ok:true, type:"LEGAL_SHOT", keepTurn:own>0};
}

function boardWinner(state) {
  const active = state.mode==="1v1" ? [0,1] : [0,2,1,3];
  let best=active[0];
  for(const s of active) if(state.scores[s] > state.scores[best]) best=s;
  return state.scores[best] > state.scores[active.find(x=>x!==best)] ? best : null;
}

module.exports={RULES,initialState,legalTurn,nextTurn,applyShotResult,boardWinner};
