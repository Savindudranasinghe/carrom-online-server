
// Deterministic 2D Carrom physics. Server uses this module as the authority.
// Coordinates are in board pixels; all inputs are clamped before simulation.
const PHYS = Object.freeze({
  min:52, max:668, pocketRadius:30, friction:0.985,
  coinRadius:17, strikerRadius:21, maxPower:1.8,
  maxFrames:900, restSpeed:0.035
});

function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function pocketAt(x,y){
  return [[55,55],[665,55],[55,665],[665,665]]
    .findIndex(([px,py])=>Math.hypot(x-px,y-py)<PHYS.pocketRadius);
}

function clonePieces(pieces){
  return pieces.map(o=>({...o,vx:Number(o.vx)||0,vy:Number(o.vy)||0,pocketed:!!o.pocketed}));
}

function simulateShot(state, intent){
  const pieces=clonePieces(state.coins||[]);
  let striker={...(state.striker||{x:360,y:605,vx:0,vy:0,pocketed:false})};
  striker.x=clamp(Number(striker.x)||360,73,647);
  striker.y=clamp(Number(striker.y)||605,73,647);
  const tx=Number(intent.x), ty=Number(intent.y);
  if(!Number.isFinite(tx)||!Number.isFinite(ty)) return {ok:false,reason:"BAD_AIM"};
  const dx=striker.x-tx, dy=striker.y-ty, len=Math.hypot(dx,dy)||1;
  const power=clamp(Number(intent.power)||0,0,PHYS.maxPower);
  striker.vx=dx/len*18*power; striker.vy=dy/len*18*power;

  let strikerPocketed=false, pocketed=[];
  for(let frame=0;frame<PHYS.maxFrames;frame++){
    const objects=[striker,...pieces.filter(p=>!p.pocketed)];
    let moving=false;
    for(const o of objects){
      if(Math.abs(o.vx)+Math.abs(o.vy)<PHYS.restSpeed){o.vx=0;o.vy=0;continue;}
      moving=true;
      o.x+=o.vx;o.y+=o.vy;o.vx*=PHYS.friction;o.vy*=PHYS.friction;
      if(o.x<PHYS.min+o.r){o.x=PHYS.min+o.r;o.vx*=-.92}
      if(o.x>PHYS.max-o.r){o.x=PHYS.max-o.r;o.vx*=-.92}
      if(o.y<PHYS.min+o.r){o.y=PHYS.min+o.r;o.vy*=-.92}
      if(o.y>PHYS.max-o.r){o.y=PHYS.max-o.r;o.vy*=-.92}
    }
    // Equal-mass elastic collision impulse.
    for(let i=0;i<objects.length;i++) for(let j=i+1;j<objects.length;j++){
      const a=objects[i],b=objects[j],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy),min=a.r+b.r;
      if(d>0&&d<min){
        const nx=dx/d,ny=dy/d,over=min-d;
        a.x-=nx*over/2;a.y-=ny*over/2;b.x+=nx*over/2;b.y+=ny*over/2;
        const rvx=b.vx-a.vx,rvy=b.vy-a.vy,rel=rvx*nx+rvy*ny;
        if(rel<0){a.vx-=nx*rel;a.vy-=ny*rel;b.vx+=nx*rel;b.vy+=ny*rel;}
      }
    }
    if(pocketAt(striker.x,striker.y)>=0){strikerPocketed=true;striker.pocketed=true;striker.vx=striker.vy=0;}
    for(const p of pieces){
      if(!p.pocketed && pocketAt(p.x,p.y)>=0){
        p.pocketed=true;p.vx=p.vy=0;pocketed.push(p);
      }
    }
    if(!moving) break;
  }
  return {
    ok:true,
    strikerPocketed,
    pocketed:pocketed.map(p=>({id:p.id,type:p.type})),
    pieces:pieces.map(p=>({id:p.id,x:p.x,y:p.y,vx:p.vx,vy:p.vy,pocketed:p.pocketed})),
    striker:{x:striker.x,y:striker.y,pocketed:striker.pocketed}
  };
}
module.exports={PHYS,simulateShot};
